Material Kit is a Free Bootstrap 4 UI Kit, with modified in content.
Using Bootsrap Material Design
Icon Flaticon Image and Google material icon
